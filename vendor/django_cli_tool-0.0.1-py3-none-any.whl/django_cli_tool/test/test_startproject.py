import pytest
import os
import subprocess
import tempfile
import shutil
from pathlib import Path


class TestStartProject:
    
    @pytest.fixture
    def temp_dir(self):
        """Create a test directory that persists"""
        # Change to parent directory where main.py is located
        main_dir = Path(__file__).parent.parent
        os.chdir(main_dir)
        
        temp_dir = main_dir / "temp"
        temp_dir.mkdir(exist_ok=True)
        return str(temp_dir)  
    
    def test_startproject_basic(self, temp_dir):
        """Test basic startproject command"""
        # Clean up existing project
        project_path = Path(temp_dir) / "testproject"
        if project_path.exists():
            shutil.rmtree(project_path)
            
        result = subprocess.run([
            "python", "main.py", "startproject", "testproject",
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        project_path = Path(temp_dir) / "testproject"
        assert project_path.exists(), "Project not created"
        
        self._check_django_structure(project_path, "testproject")
    
    def test_startproject_with_apps(self, temp_dir):
        """Test startproject with apps"""
        # Clean up existing project
        project_path = Path(temp_dir) / "myproject"
        if project_path.exists():
            shutil.rmtree(project_path)
            
        result = subprocess.run([
            "python", "main.py", "startproject", "myproject", 
            "blog", "users", "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        project_path = Path(temp_dir) / "myproject"
        
        # Check apps were created
        assert (project_path / "blog").exists(), "blog app not created"
        assert (project_path / "users").exists(), "users app not created"
        
        self._check_app_structure(project_path / "blog", "blog")
        self._check_app_structure(project_path / "users", "users")
    
    def test_startproject_with_api_flag(self, temp_dir):
        """Test startproject with API flag"""
        # Clean up existing project
        project_path = Path(temp_dir) / "apiproject"
        if project_path.exists():
            shutil.rmtree(project_path)
            
        result = subprocess.run([
            "python", "main.py", "startproject", "apiproject",
            "--api", "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        project_path = Path(temp_dir) / "apiproject"
        self._check_api_configuration(project_path, "apiproject")
    
    def test_startproject_with_app_flag(self, temp_dir):
        """Test startproject with --app flag"""
        # Clean up existing project
        project_path = Path(temp_dir) / "flagproject"
        if project_path.exists():
            shutil.rmtree(project_path)
            
        result = subprocess.run([
            "python", "main.py", "startproject", "flagproject",
            "--app", "core", "--app", "auth", "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        project_path = Path(temp_dir) / "flagproject"
        assert (project_path / "core").exists(), "core app not created"
        assert (project_path / "auth").exists(), "auth app not created"
    
    def test_startproject_existing_folder_fails(self, temp_dir):
        """Test that creating project in existing folder fails"""
        project_path = Path(temp_dir) / "existing"
        project_path.mkdir(exist_ok=True)
        
        result = subprocess.run([
            "python", "main.py", "startproject", "existing",
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 1, "Should fail when folder exists"
        assert "already exists" in result.stdout
    
    def test_startapp_basic(self, temp_dir):
        """Test basic startapp command"""
        # Clean up existing project
        project_name = "apptest_project"
        project_path = Path(temp_dir) / project_name
        if project_path.exists():
            shutil.rmtree(project_path)
            
        # First create a real Django project
        result = subprocess.run([
            "python", "main.py", "startproject", project_name,
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Project creation failed: {result.stderr}"
        
        project_path = Path(temp_dir) / project_name
        
        # Now test startapp
        result = subprocess.run([
            "python", "main.py", "startapp",
            "--app", "testapp", "--project", str(project_path)
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        app_path = project_path / "testapp"
        assert app_path.exists(), "App not created"
        self._check_app_structure(app_path, "testapp")
    
    def test_startapp_with_services_flag(self, temp_dir):
        """Test startapp with --services flag"""
        # Clean up existing project
        project_name = "servicetest_project"
        project_path = Path(temp_dir) / project_name
        if project_path.exists():
            shutil.rmtree(project_path)
            
        # First create a real Django project
        result = subprocess.run([
            "python", "main.py", "startproject", project_name,
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Project creation failed: {result.stderr}"
        
        project_path = Path(temp_dir) / project_name
        
        # Now test startapp with services
        result = subprocess.run([
            "python", "main.py", "startapp",
            "--app", "serviceapp", "--project", str(project_path), "--services"
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        app_path = project_path / "serviceapp"
        self._check_microservices_app_structure(app_path, "serviceapp")
    
    def _check_django_structure(self, project_path, project_name):
        """Check basic Django project structure"""
        # Check Django project files
        assert (project_path / "manage.py").exists(), f"manage.py not found"
        assert (project_path / project_name / "settings.py").exists(), f"settings.py not found"
        assert (project_path / project_name / "urls.py").exists(), f"urls.py not found"
        assert (project_path / project_name / "wsgi.py").exists(), f"wsgi.py not found"
        
        # Check generated files
        assert (project_path / ".env").exists(), f".env not found"
        assert (project_path / "README.md").exists(), f"README.md not found"
        
        # Check health check and logger
        assert (project_path / project_name / "health_check.py").exists(), f"health_check.py not found"
        assert (project_path / project_name / "logger.py").exists(), f"logger.py not found"
        
        # Check environment variables in settings.py
        settings_content = (project_path / project_name / "settings.py").read_text()
        assert "config('SECRET_KEY')" in settings_content, "Environment variables not configured"
        assert "config('DEBUG'" in settings_content, "DEBUG env var not configured"
    
    def _check_app_structure(self, app_path, app_name):
        """Check Django app structure"""
        assert (app_path / "views.py").exists(), f"views.py not found in {app_name}"
        assert (app_path / "urls.py").exists(), f"urls.py not found in {app_name}"
        assert (app_path / "admin.py").exists(), f"admin.py not found in {app_name}"
        assert (app_path / "apps.py").exists(), f"apps.py not found in {app_name}"
        assert (app_path / "models.py").exists(), f"models.py not found in {app_name}"
        assert (app_path / "forms.py").exists(), f"models.py not found in {app_name}"
    
    def _check_api_configuration(self, project_path, project_name):
        """Check API configuration"""
        settings_file = project_path / project_name / "settings.py"
        urls_file = project_path / project_name / "urls.py"
        
        # Check settings.py for DRF apps
        settings_content = settings_file.read_text()
        assert "rest_framework" in settings_content, "DRF not in INSTALLED_APPS"
        assert "drf_yasg" in settings_content, "drf_yasg not in INSTALLED_APPS"
        
        # Check urls.py for swagger routes
        urls_content = urls_file.read_text()
        assert "swagger" in urls_content, "Swagger route not configured"
        assert "schema_view" in urls_content, "Schema view not configured"
    
    def _check_microservices_app_structure(self, app_path, app_name):
        """Check microservices app structure"""
        # Check models folder structure
        models_dir = app_path / "models"
        assert models_dir.exists(), f"models/ folder not found in {app_name}"
        assert (models_dir / "__init__.py").exists(), f"models/__init__.py not found in {app_name}"
        
        # Check tests folder structure
        tests_dir = app_path / "tests"
        assert tests_dir.exists(), f"tests/ folder not found in {app_name}"
        assert (tests_dir / "__init__.py").exists(), f"tests/__init__.py not found in {app_name}"
        assert (tests_dir / "unit").exists(), f"tests/unit/ folder not found in {app_name}"
        assert (tests_dir / "integration").exists(), f"tests/integration/ folder not found in {app_name}"
        assert (tests_dir / "fixtures").exists(), f"tests/fixtures/ folder not found in {app_name}"
        
        # Check basic app files
        assert (app_path / "views.py").exists(), f"views.py not found in {app_name}"
        assert (app_path / "urls.py").exists(), f"urls.py not found in {app_name}"
        assert (app_path / "admin.py").exists(), f"admin.py not found in {app_name}"
        assert (app_path / "apps.py").exists(), f"apps.py not found in {app_name}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])