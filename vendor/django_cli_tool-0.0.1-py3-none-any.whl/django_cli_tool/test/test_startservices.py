import pytest
import os
import shutil
import subprocess
import tempfile
from pathlib import Path


class TestStartServices:
    
    @pytest.fixture
    def temp_dir(self):
        """Create a test directory that persists"""
        # Change to parent directory where main.py is located
        main_dir = Path(__file__).parent.parent
        os.chdir(main_dir)
        
        temp_dir = main_dir / "temp"
        temp_dir.mkdir(exist_ok=True)
        return str(temp_dir)  
    
    def test_startservices_basic(self, temp_dir):
        """Test basic startservices command"""
        # Clean up existing services
        for service in ["junto0", "cloverr0"]:
            service_path = Path(temp_dir) / service
            if service_path.exists():
                shutil.rmtree(service_path)
                
        # Run the command
        result = subprocess.run([
            "python", "main.py", "startservices", 
            "junto0", "cloverr0", 
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        # Check command succeeded
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        # Check services were created
        auth_path = Path(temp_dir) / "junto0"
        user_path = Path(temp_dir) / "cloverr0"
        
        assert auth_path.exists(), "junto0 service not created"
        assert user_path.exists(), "cloverr0 service not created"
        
        # Check Django project structure
        self._check_django_structure(auth_path, "junto0")
        self._check_django_structure(user_path, "cloverr0")
    
    def test_startservices_with_apps(self, temp_dir):
        """Test startservices with apps"""
        # Clean up existing services
        for service in ["junto", "cloverr"]:
            service_path = Path(temp_dir) / service
            if service_path.exists():
                shutil.rmtree(service_path)
                
        result = subprocess.run([
            "python", "main.py", "startservices",
            "junto:stock",
            "cloverr:asta,yami",
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        # Check services and apps
        junto_path = Path(temp_dir) / "junto"
        cloverr_path = Path(temp_dir) / "cloverr"
        
        # Check apps were created
        assert (junto_path / "stock").exists(), "stock app not created"
        assert (cloverr_path / "asta").exists(), "asta app not created"
        assert (cloverr_path / "yami").exists(), "yami app not created"
        
        # Check microservices structure
        self._check_microservices_structure(junto_path / "stock", "stock", "junto")
        self._check_microservices_structure(cloverr_path / "asta", "asta", "cloverr")
    
    def test_startapp_basic(self, temp_dir):
        """Test basic startapp command"""
        # Clean up existing project
        project_name = "basictest_project"
        project_path = Path(temp_dir) / project_name
        if project_path.exists():
            shutil.rmtree(project_path)
            
        # First create a real Django project
        result = subprocess.run([
            "python", "main.py", "startproject", project_name,
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Project creation failed: {result.stderr}"
        
        project_path = Path(temp_dir) / project_name
        
        # Now test startapp
        result = subprocess.run([
            "python", "main.py", "startapp",
            "--app", "basicapp", "--project", str(project_path)
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        app_path = project_path / "basicapp"
        assert app_path.exists(), "App not created"
        self._check_basic_app_structure(app_path, "basicapp")
    
    def test_startapp_with_services_flag(self, temp_dir):
        """Test startapp with --services flag"""
        # Clean up existing project
        project_name = "microtest_project"
        project_path = Path(temp_dir) / project_name
        if project_path.exists():
            shutil.rmtree(project_path)
            
        # First create a real Django project
        result = subprocess.run([
            "python", "main.py", "startproject", project_name,
            "--path", temp_dir
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Project creation failed: {result.stderr}"
        
        project_path = Path(temp_dir) / project_name
        
        # Now test startapp with services
        result = subprocess.run([
            "python", "main.py", "startapp",
            "--app", "microapp", "--project", str(project_path), "--services"
        ], capture_output=True, text=True, cwd=os.getcwd())
        
        assert result.returncode == 0, f"Command failed: {result.stderr}"
        
        app_path = project_path / "microapp"
        self._check_microservices_app_structure(app_path, "microapp")
    
    def _check_django_structure(self, service_path, service_name):
        """Check basic Django project structure"""
        # Check Django project files
        assert (service_path / "manage.py").exists(), f"manage.py not found in {service_name}"
        assert (service_path / service_name / "settings.py").exists(), f"settings.py not found in {service_name}"
        assert (service_path / service_name / "urls.py").exists(), f"urls.py not found in {service_name}"
        assert (service_path / service_name / "wsgi.py").exists(), f"wsgi.py not found in {service_name}"
        
        # Check generated files
        assert (service_path / ".env").exists(), f".env not found in {service_name}"
        assert (service_path / "README.md").exists(), f"README.md not found in {service_name}"
        assert (service_path / "Dockerfile").exists(), f"Dockerfile not found in {service_name}"
        assert (service_path / "docker-compose.yml").exists(), f"docker-compose.yml not found in {service_name}"
        assert (service_path / "requirements.txt").exists(), f"requirements.txt not found in {service_name}"
        assert (service_path / ".gitignore").exists(), f".gitignore not found in {service_name}"
        assert (service_path / ".dockerignore").exists(), f".dockerignore not found in {service_name}"
        
        # Check health check and logger
        assert (service_path / service_name / "health_check.py").exists(), f"health_check.py not found in {service_name}"
        assert (service_path / service_name / "logger.py").exists(), f"logger.py not found in {service_name}"
    
    def _check_microservices_structure(self, app_path, app_name, service_name):
        """Check microservices app structure"""
        # Check models folder structure
        models_dir = app_path / "models"
        assert models_dir.exists(), f"models/ folder not found in {app_name}"
        assert (models_dir / "__init__.py").exists(), f"models/__init__.py not found in {app_name}"
        assert (models_dir / "entity1_model.py").exists(), f"models/entity1_model.py not found in {app_name}"
        assert (models_dir / "entity2_model.py").exists(), f"models/entity2_model.py not found in {app_name}"
        
        # Check tests folder structure
        tests_dir = app_path / "tests"
        assert tests_dir.exists(), f"tests/ folder not found in {app_name}"
        assert (tests_dir / "__init__.py").exists(), f"tests/__init__.py not found in {app_name}"
        assert (tests_dir / "unit").exists(), f"tests/unit/ folder not found in {app_name}"
        assert (tests_dir / "integration").exists(), f"tests/integration/ folder not found in {app_name}"
        assert (tests_dir / "fixtures").exists(), f"tests/fixtures/ folder not found in {app_name}"
        
        # Check APIs structure (located in service Django project folder)
        apis_dir = Path(app_path).parent / service_name / "apis" / "v1" / app_name
        assert apis_dir.exists(), f"apis/v1/{app_name}/ folder not found"
        assert (apis_dir / "serializers").exists(), f"apis/v1/{app_name}/serializers/ folder not found"
        assert (apis_dir / "views").exists(), f"apis/v1/{app_name}/views/ folder not found"
        
        # Check basic app files
        assert (app_path / "views.py").exists(), f"views.py not found in {app_name}"
        assert (app_path / "urls.py").exists(), f"urls.py not found in {app_name}"
        assert (app_path / "admin.py").exists(), f"admin.py not found in {app_name}"
        assert (app_path / "apps.py").exists(), f"apps.py not found in {app_name}"
        # Note: serializers.py is not created for microservices (they use API structure instead)
    
    def _check_basic_app_structure(self, app_path, app_name):
        """Check basic Django app structure"""
        assert (app_path / "views.py").exists(), f"views.py not found in {app_name}"
        assert (app_path / "urls.py").exists(), f"urls.py not found in {app_name}"
        assert (app_path / "admin.py").exists(), f"admin.py not found in {app_name}"
        assert (app_path / "apps.py").exists(), f"apps.py not found in {app_name}"
        assert (app_path / "models.py").exists(), f"models.py not found in {app_name}"
        assert (app_path / "forms.py").exists(), f"forms.py not found in {app_name}"
    
    def _check_microservices_app_structure(self, app_path, app_name):
        """Check microservices app structure for standalone app"""
        # Check models folder structure
        models_dir = app_path / "models"
        assert models_dir.exists(), f"models/ folder not found in {app_name}"
        assert (models_dir / "__init__.py").exists(), f"models/__init__.py not found in {app_name}"
        
        # Check tests folder structure
        tests_dir = app_path / "tests"
        assert tests_dir.exists(), f"tests/ folder not found in {app_name}"
        assert (tests_dir / "__init__.py").exists(), f"tests/__init__.py not found in {app_name}"
        assert (tests_dir / "unit").exists(), f"tests/unit/ folder not found in {app_name}"
        assert (tests_dir / "integration").exists(), f"tests/integration/ folder not found in {app_name}"
        assert (tests_dir / "fixtures").exists(), f"tests/fixtures/ folder not found in {app_name}"
        
        # Check basic app files
        assert (app_path / "views.py").exists(), f"views.py not found in {app_name}"
        assert (app_path / "urls.py").exists(), f"urls.py not found in {app_name}"
        assert (app_path / "admin.py").exists(), f"admin.py not found in {app_name}"
        assert (app_path / "apps.py").exists(), f"apps.py not found in {app_name}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])