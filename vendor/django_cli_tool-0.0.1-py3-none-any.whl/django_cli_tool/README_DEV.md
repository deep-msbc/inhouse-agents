# Django CLI Tool - Developer Guide

A command-line tool for scaffolding Django projects with apps and boilerplate code.

## 🏗️ Project Structure

```
Django-CLI-Tool/
├── main.py              # CLI entry point
├── template_data.py     # Template content and generators
├── pyproject.toml       # Project configuration
├── main.spec           # PyInstaller spec file
└── README_DEV.md       # This file
```

## 🚀 Quick Start

### Development Setup

```bash
# Clone and navigate
git clone <repository-url>
cd Django-CLI-Tool

# Create virtual environment
python -m venv venv    # Windows
python3 -m venv venv   # Linux/Mac

# Activate environment
venv\Scripts\activate      # Windows
source venv/bin/activate   # Linux/Mac

# Install Django (auto-installed by tool, if not installed)
pip install django
```

### Run CLI Tool

```bash
# Create Django project with apps
python main.py startproject app1 app2 app3

# Create project with --app flags
python main.py startproject shop --app app1 --app app2

# Add app to existing project
python main.py startapp --project my_blog --app comment
```

## 📦 Build Executable

```bash
# Install PyInstaller
pip install pyinstaller

# Build using spec file
pyinstaller main.spec

# Or build directly
pyinstaller --onefile --name Django_CLI_tool main.py
```

## 🔧 Code Architecture

### Core Components

- **main.py**: CLI interface using argparse with two commands
- **template_data.py**: Contains boilerplate templates and generation functions

### Commands

1. **startproject**: Creates new Django project with optional apps
2. **startapp**: Adds new app to existing project

### Generated Files Per App

- `models.py` - Sample model with basic fields
- `views.py` - Basic view function
- `urls.py` - URL patterns
- `admin.py` - Admin registration
- `tests.py` - Sample test case
- `serializers.py` - DRF serializer (if needed)
- `forms.py` - Django form
- `templates/app_name/index.html` - Basic template

### Project Integration

- Automatically adds apps to `INSTALLED_APPS` in settings.py
- Adds URL includes to main urls.py
- Creates README.md with setup instructions

## 🛠️ Development

### Adding New Templates

1. Add template content to `APP_TEMPLATE` dict in `template_data.py`
2. Modify `generate_app_boilerplate()` function if needed

### Modifying CLI Commands

Edit argument parsers in `main()` function to add new options or commands.

## 📋 Requirements

- Python 3.9+
- Django (auto-installed by tool, if not installed)
- argparse (built-in)

## 🐛 Troubleshooting

- **Django not found**: Tool auto-installs Django if missing
- **Project exists**: Tool checks for existing project folders
- **Path issues**: Run from desired parent directory