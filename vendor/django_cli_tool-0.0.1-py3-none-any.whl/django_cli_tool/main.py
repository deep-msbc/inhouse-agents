import argparse

from django_cli_tool.utils.startapp import handle_startapp
from django_cli_tool.utils.startproject import handle_startproject
from django_cli_tool.utils.startservices import handle_startservices
def main() -> None:
    """
    Main entry point for the Django project generator CLI.
    Sets up the argument parser with two commands:
      - startproject: create a new Django project with optional apps.
      - startapp: create a new app inside an existing project.

    The parsed arguments determine which handler function to call.

    Args:
        None

    Returns:
        None
    """
    parser = argparse.ArgumentParser(description=" Django Project Generator CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Parser for 'startproject' command
    project_parser = subparsers.add_parser("startproject", help="Create a new Django project")
    project_parser.add_argument("project_name", type=str, help="Name of the project")
    project_parser.add_argument("extra_apps", nargs="*", help="Optional apps as positional arguments")
    project_parser.add_argument("--app", action="append", help="App(s) to create (use multiple --app)")
    project_parser.add_argument("--path", type=str, help="Path where to create the project")
    project_parser.add_argument("--auth", action="store_true", help="Include authentication app with JWT support (requires --api)")
    project_parser.add_argument("--api", action="store_true", help="Include Django REST Framework with Swagger UI")
    project_parser.set_defaults(func=handle_startproject)

    # Parser for 'startapp' command
    app_parser = subparsers.add_parser("startapp", help="Create a new app inside an existing project")
    app_parser.add_argument("--app", required=True, help="Name of the app to create")
    app_parser.add_argument("--project", required=True, help="Project folder name")
    app_parser.add_argument("--services", action="store_true", help="Generate app with microservices structure")
    app_parser.set_defaults(func=handle_startapp)

    # Parser for 'startservices' command
    startservices_parser = subparsers.add_parser("startservices", help="Create multiple Django microservices")
    startservices_parser.add_argument("services", nargs="+", help="Service definitions in format 'service:app1,app2' or just 'service'")
    startservices_parser.add_argument("--path", type=str, help="Base path where to create services")
    startservices_parser.add_argument("--auth", action="store_true", help="Include authentication service with JWT support")
    startservices_parser.set_defaults(func=handle_startservices)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()