import os
import sys
import subprocess
import argparse
from pathlib import Path

from django_cli_tool.utils.check_python import check_and_install_dependencies
from django_cli_tool.utils.color import INFO, WARNING, ERROR 
from django_cli_tool.utils.project_setup import  create_env_file, update_settings_with_env
from django_cli_tool.utils.logger_setup import create_logger_file
from django_cli_tool.utils.swagger_setup import setup_swagger_ui
from django_cli_tool.template_data import generate_readme, replace_microservice_app_content
from django_cli_tool.utils.startapp import create_apps
from django_cli_tool.utils.health_check_setup import create_health_check_file
from django_cli_tool.utils.auth_setup import  add_jwt_settings, update_requirements_with_auth
from django_cli_tool.template_data import generate_auth_app_microservices
from django_cli_tool.utils.manage_setup import override_manage_py
from django_cli_tool.utils.migration_patch_setup import migration_patch_name_convention


def handle_startservices(args: argparse.Namespace) -> None:
    """
    Handles the 'startservices' command to create multiple Django microservices.
    Parses service:app mapping and creates independent Django projects for each service.
    
    Args:
        args (argparse.Namespace): Parsed CLI args with attributes:
            services (list[str]): Service definitions in format 'service:app1,app2' or just 'service'.
            path (str): Optional base path where to create services.
            auth (bool): Include authentication service with JWT support.
    
    Returns:
        None
    """
    services_map = parse_services_mapping(args.services)
    
    # Handle path argument
    if hasattr(args, 'path') and args.path:
        target_dir = Path(args.path)
        target_dir.mkdir(parents=True, exist_ok=True)
        os.chdir(target_dir)
        print(f"{INFO} Creating microservices in: {target_dir}")
    
    # Add auth service if requested
    auth_enabled = getattr(args, "auth", False)
    if auth_enabled:
        services_map["authservice"] = ["authentication"]
        print(f"{INFO} Authentication service will be created")
    
    create_microservices(services_map, auth_enabled)

def parse_services_mapping(services_args: list[str]) -> dict[str, list[str]]:
    """
    Parses service definitions from command line arguments into a structured dictionary.
    Converts 'service:app1,app2' format into {service: [app1, app2]} mapping.
    
    Args:
        services_args (list[str]): List of service definitions from command line.
    
    Returns:
        dict[str, list[str]]: Dictionary mapping service names to their app lists.
    """
    services_map = {}
    for entry in services_args:
        if ':' in entry:
            service, apps_str = entry.split(':', 1)
            apps = [app.strip() for app in apps_str.split(',')]
            services_map[service] = apps
        else:
            services_map[entry] = []  # Service without apps
    return services_map

def create_microservices(services_map: dict[str, list[str]], auth_enabled: bool = False) -> None:
    """
    Creates multiple Django microservices based on the provided services mapping.
    For each service, creates a Django project, sets up environment configuration,
    creates specified apps, and generates project documentation.
    
    Args:
        services_map (dict[str, list[str]]): Dictionary mapping service names to their app lists.
        auth_enabled (bool): Whether authentication is enabled for services.
    
    Returns:
        None
    """
    original_dir = os.getcwd()
    # Create Django project for the service
    check_and_install_dependencies(api=True)
    # Import call_command here to avoid ModuleNotFoundError
    from django.core.management import call_command
    for service_name, apps in services_map.items():
        print(f"\n{'='*60}")
        print(f"Creating microservice: {service_name}")
        print(f"{'='*60}")
        
        # Check if service already exists using full path
        full_service_path = Path(original_dir) / service_name
        if full_service_path.exists():
            print(f"{WARNING} Service '{full_service_path}' already exists, skipping...")
            continue
            
        
        
        try:
            call_command("startproject", service_name)
            os.environ["DJANGO_SETTINGS_MODULE"] = f"{service_name}.settings"
        except Exception as e:
            print(f"{ERROR} Failed to create service '{service_name}': {e}")
            continue
        
        try:
            override_manage_py(service_name)
        except Exception as e:
            print(f"{ERROR} Failed to override manage.py: {e}")
        print(f"{INFO} Service '{service_name}' created successfully")
        
        # Create .env file first
        create_env_file(service_name)
        
        # Setup environment variables and database
        update_settings_with_env(service_name)
        create_health_check_file(service_name)
        create_logger_file(service_name)
        migration_patch_name_convention(service_name)
        
        # Create apps for this service
        if apps:
            print(f"{INFO} Creating apps for {service_name}: {', '.join(apps)}")
            
            # Handle auth service specifically
            if service_name == "authservice" and "authentication" in apps:
                os.chdir(service_name)
                print(f"{INFO} Setting up JWT authentication for {service_name}")
                
                # Create Django app first
                try:
                    call_command("startapp", "authentication")
                except Exception as e:
                    print(f"{ERROR} Failed to create authentication app: {e}")
                    os.chdir('..')
                    continue
                
                # Generate auth boilerplate and setup
                generate_auth_app_microservices(service_name)
                
                # Add JWT settings while in service directory
                add_jwt_settings(service_name)
                
                os.chdir('..')
                
                # Add authentication app to INSTALLED_APPS and URLs
                _add_app_to_settings(service_name, "authentication")
                _add_app_to_urls(service_name, "authentication")
            else:
                # Create regular microservice apps
                for app in apps:
                    # Create Django app first
                    os.chdir(service_name)
                    try:
                        call_command("startapp", app)
                    except Exception as e:
                        print(f"{ERROR} Failed to create app {app}: {e}")
                        os.chdir('..')
                        continue
                    
                    # Replace app content with microservices structure
                    os.chdir('..')
                    replace_microservice_app_content(service_name, app)
                    
                    # Add app to INSTALLED_APPS and URLs
                    _add_app_to_settings(service_name, app)
                    _add_app_to_urls(service_name, app)
        # Generate project files
        generate_readme(service_name, apps,API=True)
        setup_swagger_ui(service_name)
        
        # Add auth requirements after project files are generated
        if service_name == "authservice":
            update_requirements_with_auth(service_name)
        
        print(f"{INFO} Microservice '{service_name}' setup completed")
        
        # Return to original directory
        os.chdir(original_dir)
    
    print(f"\n{'='*60}")
    print("All microservices created successfully!")
    print("Each service can be run independently with:")
    for service_name in services_map.keys():
        print(f"  cd {service_name} && python manage.py runserver")
    print(f"{'='*60}")

def _add_app_to_settings(project_name: str, app_name: str) -> None:
    """Add app to INSTALLED_APPS in settings.py"""
    import re
    settings_file = Path(project_name) / project_name / "settings.py"
    if not settings_file.exists():
        return
    
    content = settings_file.read_text(encoding="utf-8")
    pattern = r"INSTALLED_APPS\s*=\s*\[([^\]]*)\]"
    match = re.search(pattern, content, re.DOTALL)
    
    if match:
        apps_block = match.group(1)
        # Use app config for authentication app
        if app_name == "authentication":
            app_config = "'authentication.apps.AuthenticationConfig'"
        else:
            app_config = f"'{app_name}'"
            
        if app_config not in apps_block:
            new_apps_block = apps_block + f"\n    {app_config},"
            new_content = content[:match.start(1)] + new_apps_block + content[match.end(1):]
            settings_file.write_text(new_content, encoding="utf-8")
            print(f"{INFO} Added {app_config} to INSTALLED_APPS")

def _add_app_to_urls(project_name: str, app_name: str) -> None:
    """Add app URLs to main urls.py"""
    import re
    urls_file = Path(project_name) / project_name / "urls.py"
    if not urls_file.exists():
        return
    
    content = urls_file.read_text(encoding="utf-8")
    
    # Add include import if not present
    if "from django.urls import path, include" not in content:
        content = content.replace(
            "from django.urls import path",
            "from django.urls import path, include"
        )
    
    # Add app URL pattern
    url_pattern = f"    path('{app_name}/', include('{app_name}.urls')),"
    
    # Find urlpatterns and add the new pattern
    pattern = r"urlpatterns\s*=\s*\[([^\]]*)\]"
    match = re.search(pattern, content, re.DOTALL)
    
    if match:
        urls_block = match.group(1)
        if f"'{app_name}/'" not in urls_block:
            new_urls_block = urls_block + f"\n{url_pattern}"
            new_content = content[:match.start(1)] + new_urls_block + content[match.end(1):]
            urls_file.write_text(new_content, encoding="utf-8")
            print(f"{INFO} Added '{app_name}' URLs to main urls.py")