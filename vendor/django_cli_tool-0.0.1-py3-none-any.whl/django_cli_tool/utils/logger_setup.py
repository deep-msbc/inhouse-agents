from pathlib import Path
from django_cli_tool.utils.color import INFO, WARNING, SETTINGS
from django_cli_tool.template_data import LOGGER_SETTINGS, LOGGER_TEMPLATE, LOGGER_MIDDLEWARE

def create_logger_file(project_name: str) -> None:
    """
    Creates a logger.py file with logging configuration and integrates it into Django settings.py.
    Provides structured logging capabilities for the Django project.

    Args:
        project_name (str): Name of the Django project where logging will be configured.

    Returns:
        None
    """
    project_path = Path(project_name) / project_name
    logger_file = project_path / "logger.py"
    middleware_file = project_path / "middleware.py"
    middleware_content = LOGGER_MIDDLEWARE.replace("project_name", project_name)

    # Create logger.py
    with open(logger_file, "w") as f:
        f.write(LOGGER_TEMPLATE)
    print(f"{INFO} Created logger.py")

    with open(middleware_file, "w") as f:
        f.write(middleware_content)
    print(f"{INFO} Created middleware.py")

    # Add logger configuration to settings.py
    settings_file = project_path / SETTINGS
    if settings_file.exists():
        content = settings_file.read_text(encoding="utf-8")

        # Insert logger_settings into settings.py before the first occurrence of a settings block
        if "LOGGING" not in content:
            # Find a safe place to insert LOGGING config (after DEFAULT_AUTO_FIELD is common)
            insert_pos = content.find("DEFAULT_AUTO_FIELD =")
            if insert_pos != -1:
                # Find the end of the DEFAULT_AUTO_FIELD line/statement
                DEFAULT_AUTO_FIELD_END = content.find("\n", insert_pos) + 1
                content = content[:DEFAULT_AUTO_FIELD_END] + "\n" + LOGGER_SETTINGS.replace("project_name", project_name) + "\n" + content[DEFAULT_AUTO_FIELD_END:]
            else:
                # Fallback: prepend after the first import block
                insert_pos = content.find("\n", content.find("from pathlib import Path")) + 1
                content = content[:insert_pos] + "\n" + LOGGER_SETTINGS + "\n" + content[insert_pos:]

        settings_file.write_text(content, encoding="utf-8")
        print(f"{INFO} Added logger configuration to {SETTINGS}")
    else:
        print(f"{WARNING} {SETTINGS} not found")
