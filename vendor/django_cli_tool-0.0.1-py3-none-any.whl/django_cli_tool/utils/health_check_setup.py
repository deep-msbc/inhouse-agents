import re
from pathlib import Path
from django_cli_tool.template_data import HEALTH_CHECK_TEMPLATE
from django_cli_tool.utils.color import  INFO, WARNING

def create_health_check_file(project_name: str) -> None:
    """
    Creates a health_check.py file in the Django project and adds the health check route to urls.py.
    The health check endpoint provides a simple way to verify if the service is running.
    
    Args:
        project_name (str): Name of the Django project where the health check will be created.
    
    Returns:
        None
    """
    project_path = Path(project_name) / project_name
    health_check_file = project_path / "health_check.py"
    
    # Create health_check.py
    with open(health_check_file, "w") as f:
        f.write(HEALTH_CHECK_TEMPLATE)
    print(f"{INFO} Created health_check.py")
    
    # Add health check URL to urls.py
    urls_file = project_path / "urls.py"
    if urls_file.exists():
        content = urls_file.read_text(encoding="utf-8")
        
        # Add import for health_check view before django.contrib import
        if f"from {project_name}.health_check import health_check" not in content:
            insert_pos = 0
            django_contrib_pos = re.search(r"^from django\.contrib", content, re.MULTILINE)
            if django_contrib_pos:
                # place before the django.contrib import line
                insert_pos = django_contrib_pos.start()
                content = content[:insert_pos] + f"from {project_name}.health_check import health_check\n" + content[insert_pos:]
            else:
                # Fallback: place at the beginning
                content = f"from {project_name}.health_check import health_check\n" + content        
        # Add health check route
        pattern = r"urlpatterns\s*=\s*\[([^\]]*)\]"
        match = re.search(pattern, content, re.DOTALL)
        
        if match:
            routes_block = match.group(1)
            health_route = "path('health/', health_check, name='health_check')"
            if health_route not in routes_block:
                new_routes_block = routes_block + f"\n    {health_route},"
                new_content = content[:match.start(1)] + new_routes_block + content[match.end(1):]
                urls_file.write_text(new_content, encoding="utf-8")
                print(f"{INFO} Added health check route to urls.py")
    else:
        print(f"{WARNING} urls.py not found")

