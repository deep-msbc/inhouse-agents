import sys
import os
import keyword
import subprocess
import argparse
from django_cli_tool.utils.color import ERROR, INFO, WARNING , SETTINGS
from pathlib import Path
import re
from  django_cli_tool.template_data import generate_app_boilerplate
from django.core.management import call_command

class DjangoAppCreator:
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.project_path = Path(project_name).resolve()
        self.settings_file = self.project_path / project_name / SETTINGS
        self.urls_file = self.project_path / project_name / "urls.py"
    
    def create_apps(self, apps: list[str], microservices: bool = False, api: bool = False) -> None:
        """
        Creates Django apps inside the specified project folder.
        For each app:
          - Runs 'manage.py startapp <app>'
          - Adds the app to the INSTALLED_APPS setting in settings.py
          - Adds the app's urls.py to the main urls.py
          - Generates boilerplate app files using generate_app_boilerplate

        Args:
            apps (list[str]): List of app names to create.
            microservices (bool): Whether to generate microservices structure.

        Returns:
            None
        """
        os.chdir(self.project_name)

        for app in apps:
            # Validate app name is a valid Python identifier
            if not app.isidentifier() or keyword.iskeyword(app):
                print(f"{ERROR} '{app}' is not a valid app name. Use a valid Python identifier. Skipping.")
                continue
            print(f"\nCreating app: {app}")
            print("-" * 40)
            self._create_django_app(app)
            self._update_settings(app)
            self._update_urls(app)
            self._generate_boilerplate(app, microservices, api)
    
    def _create_django_app(self, app: str) -> None:
        """Creates Django app using manage.py startapp"""
        try:
            os.environ.setdefault("DJANGO_SETTINGS_MODULE", f"{self.project_name}.settings")
            call_command("startapp", app)
        except Exception as e:
            print(f"{ERROR} Failed to create app '{app}': {e}")
            sys.exit(1)
        print(f"{INFO} App '{app}' created successfully")
    
    def _update_settings(self, app: str) -> None:
        """Updates settings.py INSTALLED_APPS with the new app"""
        if not self.settings_file.exists():
            print(f"{WARNING} settings.py not found")
            return
        
        print(f"{INFO} Configuring settings.py...")
        content = self.settings_file.read_text(encoding="utf-8")
        pattern = r"INSTALLED_APPS\s*=\s*\[([^\]]*)\]"
        match = re.search(pattern, content, re.DOTALL)
        if match:
            apps_block = match.group(1)
            if f"'{app}'" not in apps_block:
                new_apps_block = apps_block + f"\n    '{app}',"
                new_content = content[:match.start(1)] + new_apps_block + content[match.end(1):]
                self.settings_file.write_text(new_content, encoding="utf-8")
                print(f"{INFO} Added '{app}' to INSTALLED_APPS")
            else:
                print(f"{WARNING} '{app}' already in INSTALLED_APPS")
        else:
            print(f"{WARNING} Could not find INSTALLED_APPS block in settings.py")
    
    def _update_urls(self, app: str) -> None:
        """Updates urls.py urlpatterns with the new app route"""
        if not self.urls_file.exists():
            print(f"{WARNING} urls.py not found")
            return
        
        content = self.urls_file.read_text(encoding="utf-8")
        
        # Ensure include is imported
        if "from django.urls import path, include" not in content:
            content = content.replace(
                "from django.urls import path",
                "from django.urls import path, include"
            )
        
        pattern = r"urlpatterns\s*=\s*\[([^\]]*)\]"
        match = re.search(pattern, content, re.DOTALL)
        
        if match:
            routes_block = match.group(1)
            new_route = f"path('{app}/', include('{app}.urls')),"
            if new_route not in routes_block:
                new_routes_block = routes_block + f"\n    {new_route}"
                new_content = content[:match.start(1)] + new_routes_block + content[match.end(1):]
                self.urls_file.write_text(new_content, encoding="utf-8")
                print(f"{INFO} Added route for '{app}' in urls.py")
            else:
                print(f"{WARNING} Route for '{app}' already exists in urls.py")
        else:
            print(f"{WARNING} Could not find urlpatterns block in urls.py")
    
    def _generate_boilerplate(self, app: str, microservices: bool, api: bool = False,auth:bool=False) -> None:
        """Generates boilerplate files for the app"""
        print(f"{INFO} Generating boilerplate files...")
        generate_app_boilerplate(app, self.project_name, microservices, api,auth)
        print(f"{INFO} Boilerplate files created for '{app}'")

# Backward compatibility function
def create_apps(project_name: str, apps: list[str], microservices: bool = False, api: bool = False) -> None:
    """Backward compatibility wrapper for the class-based approach"""
    creator = DjangoAppCreator(project_name)
    creator.create_apps(apps, microservices, api)

def handle_startapp(args: argparse.Namespace) -> None:
    """
    Handles the 'startapp' command:
      - Checks if the specified Django project folder exists.
      - Creates a new app inside the existing project.

    Args:
        args (argparse.Namespace): Parsed CLI args with attributes:
            project (str): The project folder name or full path.
            app (str): The app name to create.

    Returns:
        None
    """
    project_path = Path(args.project)
    app_name = args.app

    if not project_path.exists():
        print(f"{ERROR} Project '{project_path}' not found.")
        sys.exit(1)

    # Extract project name from path and change to parent directory
    project_name = project_path.name
    os.chdir(project_path.parent)
    
    # Check if --services flag is provided
    microservices = getattr(args, 'services', False)
    
    # Check if project has API support by looking for DRF in settings
    api_enabled = False
    settings_file = project_path / project_name / "settings.py"
    if settings_file.exists():
        settings_content = settings_file.read_text(encoding="utf-8")
        api_enabled = "rest_framework" in settings_content

    creator = DjangoAppCreator(project_name)
    creator.create_apps([app_name], microservices, api_enabled)
