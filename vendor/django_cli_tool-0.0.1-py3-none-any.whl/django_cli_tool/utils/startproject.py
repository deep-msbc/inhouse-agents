
import sys
import os
import keyword
import subprocess
import argparse
from django_cli_tool.utils.color import ERROR, INFO, WARNING
from pathlib import Path


from django_cli_tool.utils.check_python import check_and_install_dependencies
from django_cli_tool.utils.project_setup import update_settings_with_env ,create_env_file
from django_cli_tool.utils.logger_setup import create_logger_file
from django_cli_tool.utils.swagger_setup import setup_swagger_ui
from django_cli_tool.template_data import generate_readme,generate_auth_app
from django_cli_tool.utils.auth_setup import add_jwt_settings,update_requirements_with_auth
from django_cli_tool.utils.startapp import create_apps
from django_cli_tool.utils.health_check_setup import create_health_check_file
from django_cli_tool.utils.manage_setup import override_manage_py
from django_cli_tool.utils.migration_patch_setup import migration_patch_name_convention


def handle_startproject(args: argparse.Namespace) -> None:
    """
    Handles the 'startproject' command:
      - Checks if project folder already exists, exits if yes.
      - Ensures Django is installed.
      - Creates new Django project command.
      - Creates apps specified by positional or --app flags.
      - Optionally creates 'accounts' app for auth if flag used.
      - Optionally installs Django REST framework if flag used.
      - Generates a README file with the list of apps.

    Args:
        args (argparse.Namespace): Parsed CLI args with attributes:
            project_name (str): Name of the Django project.
            extra_apps (list[str]): Extra positional apps to create.
            app (list[str] | None): Apps specified via --app flags.
            path (str): Optional path where to create the project.
            auth (bool): Include custom auth app (currently commented out).
            api (bool): Install Django REST Framework (currently commented out).

    Returns:
        None
    """
    project_name = args.project_name

    # Validate project name is a valid Python identifier
    if not project_name.isidentifier() or keyword.iskeyword(project_name):
        print(f"{ERROR} '{project_name}' is not a valid Django project name. Use a valid Python identifier.")
        sys.exit(1)

    # Determine the full project path
    if hasattr(args, 'path') and args.path:
        # Change to the specified directory
        target_dir = Path(args.path)
        target_dir.mkdir(parents=True, exist_ok=True)
        os.chdir(target_dir)
        full_project_path = target_dir / project_name
    else:
        full_project_path = Path(project_name)

    if full_project_path.exists():
        print(f"{ERROR} Project folder '{full_project_path}' already exists.")
        sys.exit(1)
    if getattr(args, "api", False):
        check_and_install_dependencies(api=True)
    else:
        check_and_install_dependencies()

    # Import call_command here to avoid ModuleNotFoundError
    from django.core.management import call_command
    try:
        call_command("startproject", project_name)
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", f"{project_name}.settings")
    except Exception as e:
        try:
            subprocess.run([sys.executable, "-m", "django", "startproject", project_name], check=True, capture_output=True, text=True)
            os.environ.setdefault("DJANGO_SETTINGS_MODULE", f"{project_name}.settings")
        except subprocess.CalledProcessError as e2:
            print(f"{ERROR} Failed to create project '{project_name}': {e2.stderr}")
            sys.exit(1)
    try:
        override_manage_py(project_name)
    except Exception as e:
        print(f"{ERROR} Failed to override manage.py: {e}")
        sys.exit(1)
    print(f"\n{INFO} Django project '{project_name}' created at '{full_project_path}'")
    print("=" * 60)

    apps = (args.app or []) + (args.extra_apps or [])
    if getattr(args, "auth", False) and getattr(args, "api", False):
        apps.append("authentication")
    elif getattr(args, "auth", False):
        print(f"{WARNING} --auth flag is ignored without --api flag")
        
    # Create .env file first
    create_env_file(project_name)
    
    # Setup PostgreSQL database configuration
    update_settings_with_env(project_name)
    create_health_check_file(project_name)
    create_logger_file(project_name)
    migration_patch_name_convention(project_name)
    if apps:
        create_apps(project_name, apps, api=getattr(args, "api", False))
        if 'authentication' in apps:
            generate_auth_app(project_name)
        os.chdir('..')
    # Enable Django REST framework installation with Swagger UI
    if getattr(args, "api", False):
        
        setup_swagger_ui(project_name)
        if 'authentication' in apps:
            add_jwt_settings(project_name)

 
    if getattr(args, "api", False):
        generate_readme(project_name, apps, API=True)
        print(f"{INFO} API documentation configured")
        if getattr(args, "auth", False):
            update_requirements_with_auth(project_name)
            print(f"{INFO} JWT authentication configured")
    else:
        generate_readme(project_name, apps)
    print(f"{INFO} README.md, .env, and project files created")
    print(f"{INFO} Configure .env file with your database and email settings")
    
    print("\n" + "=" * 60)
    print(f"Project '{project_name}' is ready!")
    print(f"Navigate to: cd {project_name}")
    print("Check README.md for setup instructions")
    print("=" * 60)
