# utils/manage_setup.py

from pathlib import Path
from django_cli_tool.utils.color import INFO
from django_cli_tool.template_data import MANAGE_PY

def override_manage_py(project_name: str) -> None:
    manage_file = Path(project_name) / "manage.py"

    if not manage_file.exists():
        return

    content = MANAGE_PY.replace("{project_name}", project_name)
    manage_file.write_text(content, encoding="utf-8")

    print(f"{INFO} Updated manage.py with shortcuts")