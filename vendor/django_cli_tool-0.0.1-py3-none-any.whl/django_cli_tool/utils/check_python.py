import itertools
import sys
import subprocess
import time
from django_cli_tool.utils.color import ERROR, INFO, WARNING
import threading
from importlib.metadata import distributions 

def get_installed_packages():
    return {dist.metadata["Name"].lower(): dist.version for dist in distributions()}

def spinner(message="Installing...") -> None:
    """
    Displays a rotating spinner animation in the terminal while a package is being installed.
    Uses itertools.cycle to continuously rotate through spinner characters.
    
    Args:
        message (str): The message to display alongside the spinner. Defaults to "Installing...".
    
    Returns:
        None
    """
    for c in itertools.cycle(['|', '/', '-', '\\']):
        if done:
            break
        sys.stdout.write(f'\r{message} {c}')
        sys.stdout.flush()
        time.sleep(0.1)
    sys.stdout.write('\r')  # clear spinner when done

def install_package(pkg_name: str) -> None:
    """
    Installs a Python package using pip with a visual loading spinner.
    Runs pip install in a subprocess while displaying a spinner animation.
    
    Args:
        pkg_name (str): Name of the package to install via pip.
    
    Returns:
        None
    """
    global done
    print(f"{WARNING} {pkg_name} not found. Installing...")

    done = False
    t = threading.Thread(target=spinner, args=(f"Installing {pkg_name}...",))
    t.start()

    # Run pip install silently
    process = subprocess.Popen(
        ['python', '-m', 'pip', 'install', pkg_name],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()
    done = True
    t.join()

    if process.returncode == 0:
        print(f"{INFO} {pkg_name} installed successfully")
    else:
        print(f"{WARNING} Failed to install {pkg_name}")
        print(stderr)

def get_installed_packages():
    return {dist.metadata["Name"].lower(): dist.version for dist in distributions()}
 
def check_and_install_dependencies(api: bool=False) -> None:
    """
    Check if Django is installed by inspecting the import spec.
    If not installed, it installs Django using pip via subprocess.

    Args:
        None

    Returns:
        None
    """
    # Check using importlib.
    installed = get_installed_packages()
    core_lib = {
        "django": "django",
        "psycopg": "psycopg[binary]"
    }
    api_lib = {
        "djangorestframework": "djangorestframework",
        "drf-yasg": "drf-yasg"
    }
    def check_and_install(lib: dict):
        for key, value in lib.items():
            if key in installed:
                print(f"{INFO} {key} already installed.")
            else:
                install_package(value)

    check_and_install(core_lib)

    if api:
        check_and_install(api_lib)