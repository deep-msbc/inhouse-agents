from pathlib import Path
from django_cli_tool.utils.color import INFO, WARNING,SETTINGS
from django_cli_tool.template_data import load_template


def add_jwt_settings(project_name: str) -> None:
    """Add JWT configuration to Django settings.py"""
    # Try both possible paths for settings.py
    settings_file1 = Path(project_name) / project_name / SETTINGS  # For startproject
    settings_file2 = Path(project_name) / SETTINGS  # For startservices
    
    if settings_file1.exists():
        settings_file = settings_file1
    elif settings_file2.exists():
        settings_file = settings_file2
    else:
        print(f"{WARNING} {SETTINGS} not found at {settings_file1} or {settings_file2}")
        return
    
    print(f"{INFO} Configuring JWT settings for {project_name}")
    
    content = settings_file.read_text(encoding="utf-8")
    
    # JWT settings to add
    jwt_settings = f'''

# JWT Configuration
JWT_PRIVATE_KEY_PATH = os.path.join(BASE_DIR, 'keys', 'private.pem')
JWT_PUBLIC_KEY_PATH = os.path.join(BASE_DIR, 'keys', 'public.pem')
JWT_ISSUER = '{project_name}'
JWT_ALGORITHM = 'RS256'

# REST Framework Configuration
REST_FRAMEWORK = {{
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
    ],
}}

# Swagger JWT Authentication
SWAGGER_SETTINGS = {{
    'SECURITY_DEFINITIONS': {{
        'Bearer': {{
            'type': 'apiKey',
            'name': 'Authorization',
            'in': 'header'
        }}
    }},
    'USE_SESSION_AUTH': False,
}}
'''
    
    # Add JWT settings if not already present
    if "JWT_PRIVATE_KEY_PATH" not in content:
        # Find the end of the file and add JWT settings
        content += jwt_settings
        settings_file.write_text(content, encoding="utf-8")
        print(f"{INFO} JWT settings added to settings.py")
    else:
        print(f"{INFO} JWT settings already present in settings.py")
        
def update_requirements_with_auth(project_name: str) -> None:
    """Add authentication requirements to requirements.txt"""
    requirements_file = Path(project_name) / "requirements.txt"
    
    if not requirements_file.exists():
        print(f"{WARNING} requirements.txt not found")
        return
    
    # Load auth requirements template
    auth_requirements = load_template("project/requirements-auth.txt")
    
    # Read current requirements
    content = requirements_file.read_text(encoding="utf-8")
    
    # Check if auth requirements already added
    if "PyJWT" not in content:
        # Add auth requirements at the end
        content += f"\n\n{auth_requirements}"
        requirements_file.write_text(content, encoding="utf-8")
        print(f"{INFO} Authentication requirements added to requirements.txt")
    else:
        print(f"{INFO} Authentication requirements already present in requirements.txt")