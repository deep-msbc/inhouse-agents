from pathlib import Path
from django_cli_tool.utils.color import ERROR, INFO
from django_cli_tool.template_data import MIGRATION_PATCH_SETTING


def migration_patch_name_convention(project_name: str) -> None:
    """
    Automatically inject the global migration naming patch into the Django project.

    What this function does:
    ----------------------------------
    1. Creates `migration_naming_patch.py` inside the project folder.
    2. Ensures that `settings.py` imports the patch:
           from <project_name>.migration_naming_patch import *
    3. Ensures the import is added cleanly after:
           from pathlib import Path
    4. Avoids duplicate imports and handles updates safely.
    """

    try:
        print(f"{INFO} Initiated migration naming patch setup")

        # Path: /<project_name>/<project_name>/
        project_path = Path(project_name) / project_name

        # Path to settings.py
        settings_file = project_path / "settings.py"

        # Path: /<project_name>/<project_name>/migration_naming_patch.py
        migration_patch = project_path / "migration_naming_patch.py"

        # Step 1: Create the migration_naming_patch.py file
        with open(migration_patch, "w", encoding="utf-8") as f:
            f.write(MIGRATION_PATCH_SETTING)

        print(f"{INFO} Created migration_naming_patch.py")

        # Step 2: Ensure settings.py imports the patch
        if settings_file.exists():

            content = settings_file.read_text(encoding="utf-8")

            # Check if import already exists
            expected_import = f"from {project_name}.migration_naming_patch import *"
            if expected_import not in content:
                print(f"{INFO} Migration patch import not found in settings.py")

                # Insert right after: from pathlib import Path
                if "from pathlib import Path" in content:
                    content = content.replace(
                        "from pathlib import Path",
                        "from pathlib import Path\n"
                        f"{expected_import}\n"
                    )

                    print(f"{INFO} Migration patch import added to settings.py")

                # Write updated content
                settings_file.write_text(content, encoding="utf-8")

            print(f"{INFO} Settings.py updated successfully")

    except Exception as e:
        print(f"{ERROR} Error while updating settings.py for migration patch: {e}")
