import re
from pathlib import Path
from django_cli_tool.utils.color import ERROR, INFO, WARNING

class SwaggerConfigurator:
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.settings_file = Path(project_name) / project_name / "settings.py"
        self.urls_file = Path(project_name) / project_name / "urls.py"
    
    def setup_swagger_ui(self) -> None:
        """
        Sets up Swagger UI for API documentation by modifying settings.py and urls.py files.
        Adds Django REST Framework and drf-yasg to INSTALLED_APPS and configures Swagger routes.
        The function is idempotent and will not add duplicate entries.
        
        Returns:
            None
        """
        self._update_settings()
        self._update_urls()
        print(f"{INFO} Swagger UI configured in {self.urls_file}")
    
    def _update_settings(self) -> None:
        """Updates settings.py with DRF and Swagger apps"""
        if not self.settings_file.exists():
            print(f"{WARNING} settings.py not found at {self.settings_file}; skipping INSTALLED_APPS update.")
            return
        
        content = self.settings_file.read_text(encoding="utf-8")
        pattern = r"INSTALLED_APPS\s*=\s*\[([^\]]*)\]"
        match = re.search(pattern, content, re.DOTALL)
        
        if match:
            apps_block = match.group(1)
            to_add = ["rest_framework", "drf_yasg", "django.contrib.staticfiles"]
            added_any = False
            
            for app in to_add:
                if (f"'{app}'" not in apps_block) and (f'"{app}"' not in apps_block):
                    apps_block += f"\n    '{app}',"
                    added_any = True
            
            if added_any:
                new_content = content[:match.start(1)] + apps_block + content[match.end(1):]
                self.settings_file.write_text(new_content, encoding="utf-8")
                print(f"{INFO} Added DRF/Swagger apps to INSTALLED_APPS")
            else:
                print(f"{INFO} INSTALLED_APPS already contains DRF/Swagger entries (no change).")
        else:
            print(f"{WARNING} Could not find INSTALLED_APPS block in {self.settings_file}")
    
    def _update_urls(self) -> None:
        """Updates urls.py with Swagger routes and imports"""
        if not self.urls_file.exists():
            self._create_minimal_urls()
        
        content = self.urls_file.read_text(encoding="utf-8")
        content = self._add_django_imports(content)
        content = self._add_drf_imports(content)
        content = self._add_schema_view(content)
        content = self._add_swagger_routes(content)
        
        self.urls_file.write_text(content, encoding="utf-8")
    
    def _create_minimal_urls(self) -> None:
        """Creates a minimal urls.py file"""
        self.urls_file.parent.mkdir(parents=True, exist_ok=True)
        minimal = (
            "from django.urls import path, include\n\n"
            "urlpatterns = [\n"
            "    # Add app routes here\n"
            "]\n"
        )
        self.urls_file.write_text(minimal, encoding="utf-8")
    
    def _add_django_imports(self, content: str) -> str:
        """Ensures Django URL imports are present"""
        import_match = re.search(r"^from\s+django\.urls\s+import\s+([^\n]+)$", content, re.MULTILINE)
        if import_match:
            modules = [m.strip() for m in re.split(r'\s*,\s*', import_match.group(1))]
            needed = set(modules) | {"path", "include"}
            new_import_line = "from django.urls import " + ", ".join(sorted(needed))
            content = content.replace(import_match.group(0), new_import_line)
        else:
            content = "from django.urls import path, include\n" + content
        return content
    
    def _add_drf_imports(self, content: str) -> str:
        """Adds DRF and drf-yasg imports"""
        if "from drf_yasg.views import get_schema_view" not in content:
            drf_imports = (
                "from drf_yasg.views import get_schema_view\n"
                "from drf_yasg import openapi\n"
                "from rest_framework.permissions import AllowAny\n\n"
            )
            django_import_pos = re.search(r"^from django\.urls import .*$", content, re.MULTILINE)
            if django_import_pos:
                insert_pos = content.find("\n", django_import_pos.end()) + 1
                content = content[:insert_pos] + drf_imports + content[insert_pos:]
            else:
                content = drf_imports + content
        return content
    
    def _add_schema_view(self, content: str) -> str:
        """Adds schema_view definition"""
        if "schema_view =" not in content:
            schema_view_code = (
                f"schema_view = get_schema_view(\n"
                f"    openapi.Info(\n"
                f"        title=\"{self.project_name} API Documentation\",\n"
                f"        default_version='v1',\n"
                f"        description=\"API documentation for {self.project_name}\",\n"
                f"        terms_of_service=\"https://www.example.com/terms/\",\n"
                f"        contact=openapi.Contact(email=\"contact@example.com\"),\n"
                f"        license=openapi.License(name=\"Your License\"),\n"
                f"    ),\n"
                f"    public=True,\n"
                f"    permission_classes=[AllowAny],\n"
                f")\n\n"
            )
            drf_import_pos = content.find("from drf_yasg.views")
            if drf_import_pos != -1:
                two_nl_pos = content.find("\n\n", drf_import_pos)
                insert_pos = two_nl_pos + 2 if two_nl_pos != -1 else drf_import_pos
                content = content[:insert_pos] + schema_view_code + content[insert_pos:]
            else:
                content = schema_view_code + content
        return content
    
    def _add_swagger_routes(self, content: str) -> str:
        """Adds Swagger and ReDoc routes to urlpatterns"""
        swagger_route = "path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),"
        redoc_route = "path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc')"

        # Guard against duplicates by checking for the route string, not the tuple
        if "name='schema-swagger-ui'" not in content:
            urlpatterns_match = re.search(r"urlpatterns\s*=\s*\[([^\]]*)\]", content, re.DOTALL)
            if urlpatterns_match:
                routes_block = urlpatterns_match.group(1)
                new_routes_block = routes_block + f"\n    {swagger_route}\n    {redoc_route}"
                content = content[:urlpatterns_match.start(1)] + new_routes_block + content[urlpatterns_match.end(1):]
            else:
                content = content + f"\n\nurlpatterns = [\n    {swagger_route}\n    {redoc_route}\n]\n"
        return content

# Backward compatibility function
def setup_swagger_ui(project_name: str) -> None:
    """Backward compatibility wrapper for the class-based approach"""
    configurator = SwaggerConfigurator(project_name)
    configurator.setup_swagger_ui()