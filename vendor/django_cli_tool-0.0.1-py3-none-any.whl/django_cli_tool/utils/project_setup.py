
import re
import secrets
from pathlib import Path
from django_cli_tool.utils.color import ERROR, INFO, WARNING

class DjangoProjectConfigurator:
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.project_path = Path(project_name)
        self.settings_file = self.project_path / project_name / "settings.py"
        self.env_file = self.project_path / ".env"
        self.urls_file = self.project_path / project_name / "urls.py"
        
    def update_settings_with_env(self) -> None:
        """
        Updates Django settings.py to use environment variables for configuration.
        Replaces hardcoded values with environment variable calls using python-decouple.
        Updates SECRET_KEY, DEBUG, ALLOWED_HOSTS, and DATABASE configuration.
        
        Returns:
            None
        """
        if not self.settings_file.exists():
            print(f"{WARNING} settings.py not found")
            return
        
        content = self.settings_file.read_text(encoding="utf-8")
        content = self._add_decouple_import(content)
        content = self._update_secret_key(content)
        content = self._update_debug(content)
        content = self._update_allowed_hosts(content)
        content = self._update_database_config(content)
        content = self._update_static_files_config(content)
        if self.urls_file.exists():
            urls_content = self.urls_file.read_text(encoding="utf-8")
            urls_content = self._update_urls_import_config(urls_content)
            urls_content = self._update_urls_config(urls_content)
            self.urls_file.write_text(urls_content, encoding="utf-8")
            print(f"{INFO} Updated urls.py with environment variables")
        
        self.settings_file.write_text(content, encoding="utf-8")
        print(f"{INFO} Updated settings.py with environment variables")
    
    def create_env_file(self) -> None:
        """
        Creates a .env file inside the project folder with Django configuration.
        Generates a cryptographically random SECRET_KEY for each project.

        Returns:
            None
        """
        secret_key = secrets.token_urlsafe(50)
        env_content = f"""# Django Settings
SECRET_KEY={secret_key}
ALLOWED_HOSTS=localhost,127.0.0.1
DEBUG=True
DJANGO_SETTINGS_MODULE={self.project_name}.settings

IP=127.0.0.1
PORT=8000
BASE_URL=http://localhost:8000

# Database Configuration
DB_NAME={self.project_name}_db
DB_USER=postgres
DB_PASSWORD=postgres
DB_HOST=localhost
DB_PORT=5432
"""
        self.env_file.write_text(env_content, encoding="utf-8")
        print(f"{INFO} Created .env file with a unique SECRET_KEY")
    
    def _add_decouple_import(self, content: str) -> str:
        """Adds decouple import to settings.py"""
        if "from decouple import config" not in content:
            content = re.sub(r"from pathlib import Path\n", "from pathlib import Path\nfrom decouple import config\nimport os\n", content)
        return content
    
    def _update_secret_key(self, content: str) -> str:
        """Updates SECRET_KEY to use environment variable"""
        return re.sub(r"SECRET_KEY\s*=\s*['\"][^'\"]*['\"]\s*", "SECRET_KEY = config('SECRET_KEY')\n", content)
    
    def _update_debug(self, content: str) -> str:
        """Updates DEBUG to use environment variable"""
        return re.sub(r"DEBUG\s*=\s*(True|False)\s*", "DEBUG = config('DEBUG', default=False, cast=bool)\n", content)
    
    def _update_allowed_hosts(self, content: str) -> str:
        """Updates ALLOWED_HOSTS to use environment variable"""
        return re.sub(r"ALLOWED_HOSTS\s*=\s*\[[^\]]*\]\s*", "ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1').split(',')\n", content)
    
    def _update_database_config(self, content: str) -> str:
        """Updates DATABASES to use environment variables"""
        db_pattern = r"DATABASES\s*=\s*\{[^}]*'default'[^}]*\}[^}]*\}"
        db_config = """DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': config('DB_NAME', default='postgres'),
        'USER': config('DB_USER', default='postgres'),
        'PASSWORD': config('DB_PASSWORD', default='postgres'),
        'HOST': config('DB_HOST', default='localhost'),
        'PORT': config('DB_PORT', default='5432'),
    }
}"""
        return re.sub(db_pattern, db_config, content, flags=re.DOTALL)
    
    def _update_static_files_config(self, content: str) -> str:
        """Updates static files configuration"""
        static_pattern = r"""STATIC_URL\s*=\s*['"]static/['"]\s*"""
        static_config = """STATIC_URL = 'static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# STATICFILES_DIRS = [
#     os.path.join(BASE_DIR, 'static'),
# ]
\n\n"""
        return re.sub(static_pattern, static_config, content)
    
    def _update_urls_config(self, urls_content: str) -> str:
        """Updates URLs configuration"""
        urls_config = """\n# Serve static files in development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
"""
        return urls_content + urls_config

    def _update_urls_import_config(self, urls_content: str) -> str:
        """Updates URLs import configuration"""
        if "from django.conf import settings" not in urls_content:
            urls_content = re.sub(r"from django.contrib import admin", "from django.contrib import admin\nfrom django.conf import settings\nfrom django.conf.urls.static import static", urls_content)
        return urls_content
       
# Backward compatibility functions
def update_settings_with_env(project_name: str) -> None:
    """Backward compatibility wrapper for the class-based approach"""
    configurator = DjangoProjectConfigurator(project_name)
    configurator.update_settings_with_env()

def create_env_file(project_name: str) -> None:
    """Backward compatibility wrapper for the class-based approach"""
    configurator = DjangoProjectConfigurator(project_name)
    configurator.create_env_file()

