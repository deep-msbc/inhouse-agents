import os
import subprocess
import sys
from pathlib import Path
import shutil
from django_cli_tool.utils.color import ERROR, INFO, WARNING

# Get the directory where this file is located (works with PyInstaller)
if getattr(sys, 'frozen', False):
    # Running as compiled executable
    TEMPLATE_DIR = Path(sys._MEIPASS) / "templates"  # type: ignore
else:
    # Running as script
    TEMPLATE_DIR = Path(__file__).parent / "templates"

def load_template(template_path: str) -> str:
    """Load template content from file or return inline fallback"""
    try:
        with open(TEMPLATE_DIR / template_path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        # Fallback to inline templates for .exe compatibility
        return get_inline_template(template_path)

def get_inline_template(template_path: str) -> str:
    """Fallback inline templates for .exe compatibility"""
    return f"# Template not found: {template_path}\n"

# Boilerplate code templates for the default app files
def get_app_template(api: bool = False):
    template = {
        "models.py": load_template("app/models.py"),
        "views.py": load_template("app/views.py"),
        "urls.py": load_template("app/urls.py"),
        "admin.py": load_template("app/admin.py"),
        "tests.py": load_template("app/tests.py"),
        "forms.py": load_template("app/forms.py")
    }
    if api:
        template["serializers.py"] = load_template("app/serializers.py")
    return template

# APP_TEMPLATE will be generated dynamically in generate_app_boilerplate

# Custom User model boilerplate for auth-enabled app
AUTH_MODEL = load_template("app/auth_model.py")

# Project templates
README_TEMPLATE = load_template("project/readme.md")
GITIGNORE_TEMPLATE = load_template("project/gitignore.txt")
DOCKERFILE_TEMPLATE = load_template("project/dockerfile.txt")
DOCKER_COMPOSE_TEMPLATE = load_template("project/docker-compose.yml")
REQUIREMENTS_TEMPLATE = load_template("project/requirements.txt")
DOCKERIGNORE_TEMPLATE = load_template("project/dockerignore.txt")
ENV_TEMPLATE = load_template("project/env.txt")
HEALTH_CHECK_TEMPLATE = load_template("project/health_check.py")
LOGGER_TEMPLATE = load_template("project/logger.py")
LOGGER_MIDDLEWARE = load_template("project/logger_middleware.py")
MANAGE_PY= load_template("project/manage.py")

DOCKER_COMPOSE_PROD_TEMPLATE = load_template("project/docker-compose-prod.yml")

REQUIREMENTS_WITH_API = load_template("project/requirements-api.txt")

MIGRATION_PATCH_SETTING = load_template("project/migration_naming_patch.py")

LOGGER_SETTINGS = load_template("project/logger_settings.py")
# Microservices templates
MICROSERVICES_TEMPLATE = {
    "views.py": load_template("microservices/views.py"),
    "admin.py": load_template("microservices/admin.py")
}

# Microservices model templates
MICROSERVICES_MODELS = {
    "entity1_model.py": load_template("microservices/entity1_model.py"),
    "entity2_model.py": load_template("microservices/entity2_model.py")
}

AUTH_FILES = {
        "models.py": load_template("auth/models.py"),
        "serializers.py": load_template("auth/serializers.py"),
        "views.py": load_template("auth/views.py"),
        "urls.py": load_template("auth/urls.py"),
        "admin.py": load_template("auth/admin.py"),
        "apps.py": load_template("auth/apps.py")
    }
AUTH_FILES_SERVICES = {
        "views.py": load_template("auth/views.py"),
        "urls.py": load_template("auth/urls.py"),
        "admin.py": load_template("auth/admin.py")
    }

# JWT-specific files (added to auth apps on top of AUTH_FILES/AUTH_FILES_SERVICES)
AUTH_NEW_FILES = {
        "jwt_utils.py": load_template("auth/jwt_utils.py"),
        "jwks_view.py": load_template("auth/jwks_view.py")
    }

def create_microservices_structure(app_path: str):
    """Create tests folder structure and delete tests.py"""
    try:
        # Delete tests.py
        tests_file = os.path.join(app_path, "tests.py")
        if os.path.exists(tests_file):
            os.remove(tests_file)
        
        # Create tests folder structure
        tests_dir = os.path.join(app_path, "tests")
        def make_dir(paths: list):
            for path in paths:
                os.makedirs(path, exist_ok=True)
        make_dir([tests_dir, os.path.join(tests_dir, "unit"), os.path.join(tests_dir, "integration"), os.path.join(tests_dir, "fixtures")])
        
        # Create __init__.py files
        def make_init(paths: list):
            for path in paths:
                with open(os.path.join(path, "__init__.py"), "w") as f:
                    f.write("# Tests package\n")
        make_init([tests_dir, os.path.join(tests_dir, "unit"), os.path.join(tests_dir, "integration"), os.path.join(tests_dir, "fixtures")])
    except OSError as e:
        print(f"Error creating microservices structure: {e}")
        raise

def create_api_structure(project_name: str, app_name: str, auth: bool = False):
    """Create APIs folder structure inside project folder (where settings.py is)"""
    try:
        project_root = os.path.join(os.getcwd(), project_name)
        apis_dir = os.path.join(project_root, "apis", "v1", app_name)
        serializers_dir = os.path.join(apis_dir, "serializers")
        views_dir = os.path.join(apis_dir, "views")
        services_dir = os.path.join(apis_dir, "services")
        
        def make_directory(paths):
            for path in paths:
                os.makedirs(path, exist_ok=True)

        # Create directory structure
        make_directory([apis_dir, serializers_dir, views_dir, services_dir])

        # Create __init__.py files for all packages (fixes missing package init bug)
        def make_init(paths):
            for path in paths:
                with open(os.path.join(path, "__init__.py"), "w") as f:
                    f.write("# API package\n")
        make_init([apis_dir, serializers_dir, views_dir,services_dir])

    except OSError as e:
        print(f"Error creating API structure: {e}")
        raise
    
    
    if auth:
        # Create view files
        auth_view = load_template("auth/views.py")
        auth_view = auth_view.replace(
        "from authenticationserializers import RegisterSerializer, LoginSerializer",
        "from authservice.apis.v1.authentication.serializers.auth_serializers import RegisterSerializer, LoginSerializer"
            )
        auth_view = auth_view.replace(
        "from authenticationmodels import AuthToken",
        "from authentication.models.auth_models import AuthToken"
            )
        auth_view = auth_view.replace(
        "from authenticationjwt_utils import generate_jwt",
        "from authentication.jwt_utils import generate_jwt"
            )
        with open(os.path.join(apis_dir, "views", "auth_views.py"), "w") as f:
            f.write(auth_view)
            
            
         # Create serializer files
        auth_serializer = load_template("auth/serializers.py").replace("app_name",app_name)
        with open(os.path.join(apis_dir, "serializers", "auth_serializers.py"), "w") as f:
            f.write(auth_serializer)
        

    else:
        # Create serializer files
        entity1_serializer = load_template("microservices/api/serializers/entity1_serializers.py").replace("app_name",app_name)
        entity2_serializer = load_template("microservices/api/serializers/entity2_serializers.py").replace("app_name", app_name)
        with open(os.path.join(apis_dir, "serializers", "entity1_serializers.py"), "w") as f:
            f.write(entity1_serializer)

        with open(os.path.join(apis_dir, "serializers", "entity2_serializers.py"), "w") as f:
            f.write(entity2_serializer)
        # Create view files
        entity1_view = load_template("microservices/api/views/entity1_views.py").replace("app_name", app_name).replace("project_name",project_name)
        entity2_view = load_template("microservices/api/views/entity2_views.py").replace("app_name", app_name).replace("project_name",project_name)
        
        with open(os.path.join(apis_dir, "views", "entity1_views.py"), "w") as f:
            f.write(entity1_view)
        with open(os.path.join(apis_dir, "views", "entity2_views.py"), "w") as f:
            f.write(entity2_view)
    
    
    
def generate_auth_app_microservices(project_name: str) -> None:
    """Generate JWT authentication app for microservices"""
    app_name = "authentication"
    app_path = os.path.join(os.getcwd(), app_name)
    
    # Generate microservices boilerplate for auth app
    generate_app_boilerplate(app_name, project_name, microservices=True, api=True, auth=True)
    
    # Use modified microservices views.py for auth
    views_content = load_template("microservices/views.py")
    views_content = views_content.replace(
        "from app_name.models.entity1_model import Entity1",
        "from authentication.models.auth_models import AuthToken"
    )
    views_content = views_content.replace(
        "items = Entity1.objects.select_related().order_by('-created_at')",
        "items = AuthToken.objects.select_related().order_by('-created_at')"
    )
    views_content = views_content.replace("project_name", project_name)
    views_content = views_content.replace("app_name", "authentication")
    
    with open(os.path.join(app_path, "views.py"), "w") as f:
        f.write(views_content)
    
    # Replace other auth files (models, serializers, urls, admin)
    auth_files_to_replace = {"models.py", "urls.py","admin.py"}
    for filename, content in AUTH_FILES.items():
        if filename in auth_files_to_replace:
            file_path = os.path.join(app_path, filename)
            with open(file_path, "w") as f:
                # Modify admin.py import for microservices structure
                if filename == "admin.py":
                    content = content.replace(
                        "from authenticationmodels import AuthToken",
                        "from authentication.models.auth_models import AuthToken"
                    )
                if filename == "urls.py":
                    content = load_template("auth/urls_services.py")
                
                
                f.write(content)
    
    # Add new JWT-specific files
    for filename, content in AUTH_NEW_FILES.items():
        file_path = os.path.join(app_path, filename)
        with open(file_path, "w") as f:
            f.write(content)
            
    jwks_file = os.path.join(app_path, 'jwks_view.py')
    with open(jwks_file, "w") as f:
        content = load_template("auth/jwks_view.py").replace('auth.jwt_utils','authentication.jwt_utils')
        f.write(content)
        
    files_to_remove = ["forms.py", "tests.py","serializers.py"]
    for file in files_to_remove:
        file_path = os.path.join(app_path, file)
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"{INFO} Removed {file}")
        except OSError as e:
            print(f"{ERROR}: removing {file_path}: {e}")
            
    # Remove templates directory
    templates_dir = os.path.join(app_path, "templates")
    if os.path.exists(templates_dir):
        shutil.rmtree(templates_dir)
        print(f"{INFO} Removed templates directory")
        
    # Create keys directory for JWT keys
    keys_dir = os.path.join(os.getcwd(), "keys")
    os.makedirs(keys_dir, exist_ok=True)
    print(f"{INFO} Created keys directory for JWT authentication")

def generate_auth_app(project_name: str) -> None:
    """Generate regular auth app for startproject (not microservices)"""
    app_name = "authentication"
    app_path = os.path.join(os.getcwd(), app_name)
    
    # Replace existing Django-generated files with our custom content
    for filename, content in AUTH_FILES.items():
        file_path = os.path.join(app_path, filename)
        with open(file_path, "w") as f:
            f.write(content)
    
    # Add new JWT-specific files
    for filename, content in AUTH_NEW_FILES.items():
        file_path = os.path.join(app_path, filename)
        with open(file_path, "w") as f:
            f.write(content)
    
    # Remove unwanted files for startproject auth app
    files_to_remove = ["forms.py", "tests.py"]
    for file in files_to_remove:
        file_path = os.path.join(app_path, file)
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"{INFO} Removed {file}")
        except OSError as e:
            print(f"{ERROR}: removing {file_path}: {e}")
    
    # Remove templates directory
    templates_dir = os.path.join(app_path, "templates")
    if os.path.exists(templates_dir):
        shutil.rmtree(templates_dir)
        print(f"{INFO} Removed templates directory")
            
    print(f"{INFO} Generated auth app files")
    
    
            

    
def generate_app_boilerplate(app_name: str, project_name: str, microservices: bool = False, api: bool = False, auth:bool=False) -> None:
    """
    Generates default boilerplate files for a Django app.

    It writes default models.py, views.py, urls.py, admin.py, tests.py,
    and forms.py files from APP_TEMPLATE, replacing the
    placeholder 'app_name' with the actual app name.
    
    If api=True, also creates serializers.py.

    Also creates a templates directory with a basic index.html.

    Args:
        app_name (str): The app name to generate boilerplate for.
        project_name (str): The project name.
        microservices (bool, optional): If True, generate microservices structure. Defaults to False.
        api (bool, optional): If True, include serializers.py. Defaults to False.

    Returns:
        None
    """
    app_path = os.path.join(os.getcwd(), app_name)
    
    # Get the appropriate template based on API flag
    APP_TEMPLATE = get_app_template(api)
    
    if microservices:
        # Create models folder with separate model files
        models_dir = os.path.join(app_path, "models")
        os.makedirs(models_dir, exist_ok=True)
        
        # Delete models.py
        models_file = os.path.join(app_path, "models.py")
        if os.path.exists(models_file):
            os.remove(models_file)
        
        # Create __init__.py for models package
        with open(os.path.join(models_dir, "__init__.py"), "w") as f:
            f.write("# Models package\n")
        
        # Create separate model files
        if not auth:
            for filename, content in MICROSERVICES_MODELS.items():
                file_path = os.path.join(models_dir, filename)
                with open(file_path, "w") as f:
                    app_change = content.replace("app_name", app_name)
                    project_name_change = app_change.replace("project_name", project_name)
                    f.write(project_name_change)
        else:
            filename = "auth_models.py"
            content = load_template("auth/models.py")
            file_path = os.path.join(models_dir, filename)
            with open(file_path, "w") as f:
                f.write(content)
            
            # Remove the duplicate models.py file for auth apps
            models_file = os.path.join(app_path, "models.py")
            if os.path.exists(models_file):
                os.remove(models_file)
                print(f"{INFO} Removed duplicate models.py file")
                    
                    
        # Create microservices structure
        create_microservices_structure(app_path)
        
        # Create API structure for microservices
        create_api_structure(project_name, app_name,auth)
        
        # Use microservices templates for views.py and admin.py (skip for auth apps)
        if not auth:
            for filename, content in MICROSERVICES_TEMPLATE.items():
                file_path = os.path.join(app_path, filename)
                with open(file_path, "w") as f:
                    app_change = content.replace("app_name", app_name)
                    project_name_change = app_change.replace("project_name", project_name)
                    f.write(project_name_change)
        
        # Add JWT-specific files only for auth apps
        if auth:
            for filename, content in AUTH_NEW_FILES.items():
                file_path = os.path.join(app_path, filename)
                with open(file_path, "w") as f:
                    f.write(content)
        
        # Use standard templates for urls.py and serializers.py (if API enabled)
        allowed_files = ["urls.py"]
        if api:
            allowed_files.append("serializers.py")
            
        for filename, content in APP_TEMPLATE.items():
            if filename in allowed_files:
                file_path = os.path.join(app_path, filename)
                with open(file_path, "w") as f:
                    app_change = content.replace("app_name", app_name)
                    project_name_change = app_change.replace("project_name", project_name)
                    f.write(project_name_change)
        
        # Delete forms.py and tests.py (handled separately)
        forms_file = os.path.join(app_path, "forms.py")
        if os.path.exists(forms_file):
            os.remove(forms_file)
    else:
        # Standard app structure with single models.py
        for filename, content in APP_TEMPLATE.items():
            file_path = os.path.join(app_path, filename)
            with open(file_path, "w") as f:
                app_change = content.replace("app_name", app_name)
                project_name_change = app_change.replace("project_name", project_name)
                f.write(project_name_change)

        # Create template folder with placeholder index.html
        template_dir = os.path.join(app_path, "templates", app_name)
        os.makedirs(template_dir, exist_ok=True)
        with open(os.path.join(template_dir, "index.html"), "w") as f:
            f.write(f"<h1>{app_name.capitalize()} Index Page</h1>")



def generate_readme(project_name: str, apps: list[str], API: bool=False) -> None:
    """
    Generates a README.md file for the Django project.

    It lists all apps included in the project with setup instructions.

    Args:
        project_name (str): Name of the Django project.
        apps (list[str]): List of app names included in the project.

    Returns:
        None
    """
    apps_list = "\n".join([f"- {app}" for app in apps])

    readme_content = README_TEMPLATE.format(
        project_name=project_name,
        apps_list=apps_list,
    )

    generate_project_files(project_name, readme_content, API)

def replace_microservice_app_content(service_name: str, app_name: str) -> None:
    """
    Replace Django app content with microservices structure for regular services.
    This function is called after Django's startapp to customize the app structure.
    
    Args:
        service_name (str): Name of the service/project
        app_name (str): Name of the app to customize
    """
    app_path = os.path.join(service_name, app_name)
    
    # Generate microservices boilerplate
    os.chdir(service_name)
    generate_app_boilerplate(app_name, service_name, microservices=True, api=True, auth=False)
    os.chdir('..')
    
    print(f"{INFO} Replaced {app_name} with microservices structure")



def generate_project_files(project_name: str, readme_content: str, API: bool=False) -> None:
    """
    Generates common project files like README.md, .gitignore, Dockerfile and docker-compose.yml

    Args:
        project_name (str): Name of the Django project
        readme_content (str): Content for the README.md file

    Returns:
        None
    """
    ALL_REQUIREMENTS = REQUIREMENTS_TEMPLATE + (REQUIREMENTS_WITH_API if API else "")
    # Dictionary mapping filenames to their content
    files_to_create = {
        "README.md": readme_content,
        ".gitignore": GITIGNORE_TEMPLATE,
        "Dockerfile": DOCKERFILE_TEMPLATE,
        "docker-compose.yml": DOCKER_COMPOSE_TEMPLATE,
        "docker-compose.prod.yml": DOCKER_COMPOSE_PROD_TEMPLATE,
        "requirements.txt": ALL_REQUIREMENTS,
        ".dockerignore": DOCKERIGNORE_TEMPLATE
    }

    # Create all files in the project directory
    for filename, content in files_to_create.items():
        try:
            file_path = os.path.join(project_name, filename)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
        except IOError as e:
            print(f"Error creating file {filename}: {e}")
            raise
