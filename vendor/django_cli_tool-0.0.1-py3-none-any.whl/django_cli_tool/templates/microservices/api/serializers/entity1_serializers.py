from rest_framework import serializers
from app_name.models.entity1_model import Entity1

class Entity1Serializer(serializers.ModelSerializer):
    class Meta:
        model = Entity1
        fields = '__all__'

class Entity1CreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Entity1
        fields = '__all__'

class Entity1UpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Entity1
        fields = '__all__'