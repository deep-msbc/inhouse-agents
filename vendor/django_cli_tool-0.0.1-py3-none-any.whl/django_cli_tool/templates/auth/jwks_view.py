from django.http import JsonResponse
from authentication.jwt_utils import load_public_key
import base64


def jwks_view(request):
    """JWKS endpoint for JWT token validation"""
    try:
        public_key = load_public_key()
        
        public_numbers = public_key.public_numbers()
        n = public_numbers.n
        e = public_numbers.e
        
        def int_to_base64url(val):
            val_bytes = val.to_bytes((val.bit_length() + 7) // 8, 'big')
            return base64.urlsafe_b64encode(val_bytes).decode('ascii').rstrip('=')
        
        jwk = {
            "kty": "RSA",
            "use": "sig",
            "kid": "auth-service-key",
            "n": int_to_base64url(n),
            "e": int_to_base64url(e),
            "alg": "RS256"
        }
        
        return JsonResponse({"keys": [jwk]})
        
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)