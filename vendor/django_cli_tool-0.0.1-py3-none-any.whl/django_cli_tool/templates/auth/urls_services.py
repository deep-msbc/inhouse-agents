from django.urls import path
from authservice.apis.v1.authentication.views import auth_views
from authentication.jwks_view import jwks_view

urlpatterns = [
    path('register/', auth_views.register, name='register'),
    path('login/', auth_views.login, name='login'),
    path('.well-known/jwks.json', jwks_view, name='jwks'),
]