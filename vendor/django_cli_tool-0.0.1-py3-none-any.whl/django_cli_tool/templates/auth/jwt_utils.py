import jwt
from datetime import datetime, timedelta
from django.conf import settings
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
import os
import uuid


def generate_rsa_keys():
    """Generate RSA key pair if not exists"""
    if not os.path.exists(settings.JWT_PRIVATE_KEY_PATH):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        
        os.makedirs(os.path.dirname(settings.JWT_PRIVATE_KEY_PATH), exist_ok=True)
        
        with open(settings.JWT_PRIVATE_KEY_PATH, 'wb') as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
        
        public_key = private_key.public_key()
        with open(settings.JWT_PUBLIC_KEY_PATH, 'wb') as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))


def load_private_key():
    """Load private key from file"""
    generate_rsa_keys()
    with open(settings.JWT_PRIVATE_KEY_PATH, 'rb') as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def load_public_key():
    """Load public key from file"""
    generate_rsa_keys()
    with open(settings.JWT_PUBLIC_KEY_PATH, 'rb') as f:
        return serialization.load_pem_public_key(f.read())


def generate_jwt(user_id, email):
    """Generate JWT token with JTI for blacklisting"""
    private_key = load_private_key()
    
    jti = str(uuid.uuid4())
    payload = {
        "sub": str(user_id),
        "email": email,
        "jti": jti,
        "iat": datetime.utcnow(),
        "exp": datetime.utcnow() + timedelta(hours=1),
        "iss": settings.JWT_ISSUER,
    }
    
    token = jwt.encode(payload, private_key, algorithm=settings.JWT_ALGORITHM)
    return token, jti


def validate_jwt(token):
    """Validate JWT token using local public key"""
    try:
        if not token:
            return None
        
        public_key = load_public_key()
        payload = jwt.decode(
            token,
            public_key,
            algorithms=[settings.JWT_ALGORITHM],
            issuer=settings.JWT_ISSUER
        )
        
        if not payload.get('sub') or not payload.get('email'):
            return None
            
        return payload
    except (jwt.InvalidTokenError, jwt.ExpiredSignatureError, Exception):
        return None