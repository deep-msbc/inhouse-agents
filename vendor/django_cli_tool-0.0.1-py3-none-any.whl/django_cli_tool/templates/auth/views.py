from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from authentication.serializers import RegisterSerializer, LoginSerializer
from authentication.models import AuthToken
from authentication.jwt_utils import generate_jwt
from datetime import datetime, timedelta
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi


@swagger_auto_schema(
    method='post',
    request_body=RegisterSerializer,
    responses={201: 'User registered successfully', 400: 'Bad Request'}
)
@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    serializer = RegisterSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        token, jti = generate_jwt(user.id, user.email)
        
        # Store token in database
        AuthToken.objects.create(
            user=user,
            token=token,
            jti=jti,
            expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        
        return Response({
            'message': 'User registered successfully',
            'token': token,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email
            }
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@swagger_auto_schema(
    method='post',
    request_body=LoginSerializer,
    responses={200: 'Login successful', 400: 'Bad Request'}
)
@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    serializer = LoginSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.validated_data['user']
        token, jti = generate_jwt(user.id, user.email)
        
        # Store token in database
        AuthToken.objects.create(
            user=user,
            token=token,
            jti=jti,
            expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        
        return Response({
            'message': 'Login successful',
            'token': token,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email
            }
        }, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)