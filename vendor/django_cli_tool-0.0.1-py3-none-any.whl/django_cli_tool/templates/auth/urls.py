from django.urls import path
from authentication import views
from authentication.jwks_view import jwks_view

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('.well-known/jwks.json', jwks_view, name='jwks'),
]