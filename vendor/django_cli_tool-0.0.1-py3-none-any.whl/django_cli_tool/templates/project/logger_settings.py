DYNAMIC_LOG_PATH = os.path.join(BASE_DIR, "Logs")

EXTRA_MIDDLEWARE = [
    'project_name.middleware.HTTPLoggingMiddleware',
]
MIDDLEWARE += EXTRA_MIDDLEWARE
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'WARNING',
    },
}