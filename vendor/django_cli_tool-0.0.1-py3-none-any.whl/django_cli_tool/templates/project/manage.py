# Standard library imports
import os
import sys

# Third-party imports
from decouple import config


def main():
    """
    Enhanced Django management function with shortcuts and auto-configuration.
    
    Loads configuration from environment variables and provides convenient
    command shortcuts for common Django management tasks.
    
    Environment Variables:
        - PORT: Server port number
        - BASE_URL: Base URL for the application
        - IP: IP address to bind server to
    """
    
    # Load configuration from environment variables
    port = config('PORT', default='8000')
    base_url = config('BASE_URL', default='http://localhost:8000')
    ip = config('IP', default='[IP_ADDRESS]')
    # Set default Django settings module
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', '{project_name}.settings')
    
    # Import Django management utilities with error handling
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    # ==========================================================================
    # COMMAND PROCESSING AND SHORTCUTS
    # ==========================================================================
    
    if len(sys.argv) == 1:
        # No arguments provided - default to runserver with configured IP and port
        sys.argv += ['runserver', f'{ip}:{port}']
        
    elif len(sys.argv) == 2:
        # Single argument - check for command shortcuts
        command = sys.argv[1]
        
        # Command shortcut mappings for developer convenience
        shortcuts = {
            'm': 'migrate',              # Database migration
            'mm': 'makemigrations',      # Create new migrations
            'sm': 'showmigrations',      # Show migration status
            'user': 'createsuperuser',   # Create admin user
            'sh': 'shell',               # Django shell
            'r': 'runserver',            # Development server
            'cs': 'collectstatic'        # Collect static files
        }
        
        # Apply shortcut if found
        if command in shortcuts:
            sys.argv[1] = shortcuts[command]
            
    # ==========================================================================
    # STARTUP INFORMATION DISPLAY
    # ==========================================================================
    # Only print startup info once (avoid double printing during auto-reload)
    if (len(sys.argv) > 1 and 
        sys.argv[1] == 'runserver' and 
        not os.environ.get('RUN_MAIN')):
        
        # Startup information (currently commented out)
        print(f"Starting Django app on port {port}")
        print(f"Direct Django: {base_url}:{port}/health/\n")
        print(f"Reverse proxy (through nginx): {base_url}/health/")
        print(f"Reverse proxy (through nginx): {base_url}/swagger/\n")
    # ==========================================================================
    # COMMAND EXECUTION WITH ERROR HANDLING
    # ==========================================================================
    try:
        # Execute the Django management command
        execute_from_command_line(sys.argv)
    except Exception as e:
        # Enhanced error reporting for debugging
        print(f"Error starting Django: {e}")
        import traceback
        traceback.print_exc()
    


if __name__ == '__main__':
    main()
