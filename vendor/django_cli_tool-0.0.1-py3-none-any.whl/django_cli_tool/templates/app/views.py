from django.shortcuts import render
from django.core.paginator import Paginator
from django.db import DatabaseError
from app_name.models import SampleModel

def index(request):
    try:
        
        items = SampleModel.objects.select_related().order_by('-created_at')
        
        # Add pagination
        paginator = Paginator(items, 25)  # Show 25 items per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'app_name/index.html', {'page_obj': page_obj})
        
    except DatabaseError as e:
        return render(request, 'app_name/error.html', {'error': 'Database connection error'})
    except Exception as e:
        return render(request, 'app_name/error.html', {'error': 'An unexpected error occurred'})