from django.contrib import admin
from app_name.models import SampleModel


@admin.register(SampleModel)
class SampleModelAdmin(admin.ModelAdmin):
    list_display = ['title', 'status', 'created_at', 'updated_at']
    list_filter = ['status', 'created_at']
    search_fields = ['title']
    ordering = ['-created_at']
    readonly_fields = ['created_at', 'updated_at']
    list_per_page = 25
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'status')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def save_model(self, request, obj, form, change):
        try:
            logger.info(f"Admin saving SampleModel by {request.user}")
            super().save_model(request, obj, form, change)
            logger.info(f"Admin saved SampleModel: {obj.pk}")
        except Exception as e:
            logger.error(f"Error saving SampleModel in admin: {e}")
            raise
    
    def delete_model(self, request, obj):
        try:
            logger.warning(f"Admin deleting SampleModel: {obj.pk}")
            super().delete_model(request, obj)
            logger.info(f"Admin deleted SampleModel")
        except Exception as e:
            logger.error(f"Error deleting SampleModel in admin: {e}")
            raise