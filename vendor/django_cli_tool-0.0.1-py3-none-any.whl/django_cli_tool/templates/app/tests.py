from django.test import TestCase, Client
from django.urls import reverse
from django.core.exceptions import ValidationError
from app_name.models import SampleModel
from django.contrib.auth.models import User

class SampleModelTest(TestCase):
    def setUp(self):
        self.sample_data = {
            'title': 'Test Sample',
            'status': 'active'
        }
    
    def test_model_creation(self):
        obj = SampleModel.objects.create(**self.sample_data)
        self.assertEqual(obj.title, 'Test Sample')
        self.assertEqual(obj.status, 'active')
        self.assertTrue(obj.created_at)
        self.assertTrue(obj.updated_at)
    
    def test_model_str_representation(self):
        obj = SampleModel.objects.create(**self.sample_data)
        self.assertEqual(str(obj), 'Test Sample')
    
    def test_model_validation(self):
        with self.assertRaises(ValidationError):
            obj = SampleModel(title='AB', status='active')
            obj.full_clean()
    
    def test_model_choices(self):
        valid_statuses = ['active', 'inactive', 'pending']
        for status in valid_statuses:
            obj = SampleModel.objects.create(title='Test', status=status)
            self.assertEqual(obj.status, status)

class SampleModelViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123'
        )
        for i in range(30):
            SampleModel.objects.create(
                title=f'Test Item {i}',
                status='active'
            )
    
    def test_index_view_status_code(self):
        response = self.client.get(reverse('index'))
        self.assertEqual(response.status_code, 200)
    
    def test_index_view_pagination(self):
        response = self.client.get(reverse('index'))
        self.assertContains(response, 'page_obj')
        self.assertTrue('page_obj' in response.context)
    
    def test_index_view_with_authenticated_user(self):
        self.client.login(username='testuser', password='testpass123')
        response = self.client.get(reverse('index'))
        self.assertEqual(response.status_code, 200)