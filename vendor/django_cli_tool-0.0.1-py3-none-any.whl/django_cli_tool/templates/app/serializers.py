from rest_framework import serializers

# Add your serializers here
# Example:
# class YourModelSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = YourModel
#         fields = '__all__'