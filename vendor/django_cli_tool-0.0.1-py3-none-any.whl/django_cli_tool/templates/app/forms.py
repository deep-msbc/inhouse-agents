from django import forms
from app_name.models import SampleModel


class SampleModelForm(forms.ModelForm):
    class Meta:
        model = SampleModel
        fields = ['title', 'status']
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'Enter title (3-100 characters)'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }
    
    def clean_title(self):
        title = self.cleaned_data.get('title')
        if title:
            title = title.strip()
            if len(title) < 3:
                raise forms.ValidationError('Title must be at least 3 characters long')
            if not title.replace(' ', '').isalnum():
                raise forms.ValidationError('Title can only contain letters, numbers and spaces')

        return title
    
    def clean(self):
        cleaned_data = super().clean()
        title = cleaned_data.get('title')
        if title:
            cleaned_data['title'] = title.title()
        return cleaned_data
    
    def save(self, commit=True):
        try:
            instance = super().save(commit)
            return instance
        except Exception as e:
            print(e)
            raise