from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import MaxLengthValidator

class CustomUser(AbstractUser):
    bio = models.TextField(
        blank=True,
        max_length=500,
        validators=[MaxLengthValidator(500, 'Bio cannot exceed 500 characters')],
        help_text='Optional bio (max 500 characters)'
    )
    
    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['username']),
        ]