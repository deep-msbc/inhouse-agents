from django.db import models
from django.core.validators import MinLengthValidator, RegexValidator


class SampleModel(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('pending', 'Pending'),
    ]
    
    title = models.CharField(
        max_length=100,
        validators=[
            MinLengthValidator(3, 'Title must be at least 3 characters long'),
            RegexValidator(r'^[a-zA-Z0-9\s]+$', 'Title can only contain letters, numbers and spaces')
        ],
        help_text='Enter a descriptive title (3-100 characters)'
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='active',
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Sample Model'
        verbose_name_plural = 'Sample Models'
        indexes = [
            models.Index(fields=['status', 'created_at']),
        ]
        # constraints = [
        #     models.CheckConstraint(
        #         check=models.Q(title__length__gte=3),
        #         name='title_min_length'
        #     ),
        # ]

    def __str__(self):
        return self.title
    
    def clean(self):
        if self.title:
            self.title = self.title.strip().title()
    
    def save(self, *args, **kwargs):
        try:
            super().save(*args, **kwargs)
        except Exception as e:
            print("ERROR:",e)
            raise
    
    def delete(self, *args, **kwargs):
        try:
            
            result = super().delete(*args, **kwargs)
           
            return result
        except Exception as e:
            print("ERROR:",e)
            raise