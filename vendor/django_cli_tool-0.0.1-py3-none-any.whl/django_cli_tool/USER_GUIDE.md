## Quick Start Examples

### Single Project Example
```bash
# Create a blog project with authentication
Django_CLI_tool.exe startproject myblog post comment user --api --auth

cd myblog

# Activate environment (auto-created)
venv\Scripts\activate      # Windows
source venv/bin/activate   # Linux/Mac

# Configure .env file
# Update database credentials and secret key

# Setup database
python manage.py makemigrations
python manage.py migrate

# Create superuser (optional)
python manage.py createsuperuser

# Run server
python manage.py runserver
```

### Microservices Example
```bash
# Create microservices architecture with authentication
Django_CLI_tool.exe startservices user:user_app,profile_app payment:payment_app --auth --path ./microservices

cd microservices

# Setup each service
# Terminal 1 - Auth Service
cd authservice
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 8001

# Terminal 2 - User Service  
cd user 
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 8002

# Terminal 3 - Payment Service
cd payment 
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 8003
```

### Access Your Applications
- **Single Project**: `http://127.0.0.1:8000/`
- **Auth Service**: `http://127.0.0.1:8001/`
  - Login: `http://127.0.0.1:8001/auth/login/`
  - Register: `http://127.0.0.1:8001/auth/register/`
  - JWKS: `http://127.0.0.1:8001/.well-known/jwks.json`
- **User Service**: `http://127.0.0.1:8002/`
- **Payment Service**: `http://127.0.0.1:8003/`